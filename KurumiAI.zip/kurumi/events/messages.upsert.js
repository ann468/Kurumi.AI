import {
    isJidGroup,
    isJidUser,
    isJidStatusBroadcast,
    isJidNewsletter,
    jidDecode,
    jidNormalizedUser,
    getContentType,
    jidEncode
} from "@whiskeysockets/baileys";
import notifyEvent from "../utils/notifyEvent.js";

export default async function messageUpsert(bot, m) {
    try {
        if (!m.message) return;
        m.id = m.key.id;
        m.chat = m.key.remoteJid;
        m.isGroup = isJidGroup(m.chat);
        m.isPrivate = isJidUser(m.chat);
        m.isStory = isJidStatusBroadcast(m.chat);
        m.Newsletter = isJidNewsletter(m.chat);
        m.sender = m.isNewsletter
            ? ""
            : m.isGroup || m.isStory
            ? m.key.participant || jidNormalizedUser(m.participant)
            : m.key.remoteJid;
        m.fromMe = m.key.fromMe;
        m.isOwner = jidDecode(m.sender).user === global.owner.number;
        m.isPremium = !!global.db.premium.find(
            user => jidEncode(user, "s.whatsapp.net") === m.sender
        );
        m.type = getContentType(m.message);
        m.body =
            m.type === "conversation"
                ? m.message.conversation
                : m.message[m.type].caption ||
                  m.message[m.type].text ||
                  m.message[m.type].singleSelectReply?.selectedRowId ||
                  m.message[m.type].selectedButtonId ||
                  (m.message[m.type].nativeFlowResponseMessage?.paramsJson
                      ? JSON.parse(
                            m.message[m.type].nativeFlowResponseMessage
                                .paramsJson
                        ).id
                      : "") ||
                  "";
        m.text =
            m.type === "conversation"
                ? m.message.conversation
                : m.message[m.type].caption ||
                  m.message[m.type].text ||
                  m.message[m.type].description ||
                  m.message[m.type].title ||
                  m.message[m.type].contentText ||
                  m.message[m.type].selectedDisplayText ||
                  "";
        m.isCommand = m.body.trim().startsWith(global.bot.prefix);
        m.cmd = m.body
            .trim()
            .normalize("NFKC")
            .replace(global.bot.prefix, "")
            .split(" ")[0]
            .toLowerCase();
        m.args = m.body
            .trim()
            .replace(/^\S*\b/g, "")
            .split(global.bot.splitArgs)
            .map(arg => arg.trim().normalize("NFKC"))
            .filter(arg => arg);
        m.reply = text =>
            bot.sendMessage(
                m.chat,
                {
                    text
                },
                {
                    quoted: {
                        key: {
                            id: m.id,
                            fromMe: false,
                            remoteJid: "status@broadcast",
                            participant: "0@s.whatsapp.net"
                        },
                        message: {
                            conversation: `💬 ${m.text}`
                        }
                    }
                }
            );
        try {
            notifyEvent(
                "Message Upsert",
                `
Dari: ${m.sender}
Nama: ${m.pushName || "No Name"}
Pesan: ${m.text}
`.trim()
            );
            for await (let command of global.bot.commands) {
                if (command.command === m.cmd && command.handler) {
                    /// Jika private
                    if (command.handler["private"] === true && m.isGroup)
                        return;
                    /// Jika onlyOwner true dan juga dari bot atau owner
                    if (
                        command.handler["onlyOwner"] === true &&
                        !m.isOwner &&
                        !m.fromMe
                    )
                        return m.reply(
                            "Perintah ini hanya bisa di gunakan oleh owner"
                        );
                    if (
                        command.handler["onlyPremium"] &&
                        !m.isOwner &&
                        !m.fromMe &&
                        !m.isPremium
                    )
                        return m.reply(
                            "Perintah ini hanya bisa di gunakan oleh user premium"
                        );
                    console.log(`\x1b[44;1m\x20COMMAND\x20\x1b[0m\x20${m.cmd}`);
                    await command.handler(bot, m);
                    return;
                }
            }
            switch (m.cmd) {
                case "menu-case":
                    {
                        m.reply("menu Case");
                    }
                    break;
                default:
                    break;
            }
        } catch (err) {
            notifyEvent(
                "Message Upsert",
                `
Dari: ${m.sender}
Nama: ${m.pushName || "No Name"}
Pesan: ${m.text}
Error: ${err.message}
`.trim(),
                "error"
            );
            console.log(err);
            m.reply(`*ERROR:* ${err.message}`);
        }
    } catch (err) {
        console.log(err);
    }
}
