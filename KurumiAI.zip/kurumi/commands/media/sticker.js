export function handler(bot, m) {
    console.log(m);
    m.reply("Ini sebuah perintah sticker");
    return bot;
}

handler.private = false;
handler.onlyOwner = false;
handler.onlyPremium = true;
