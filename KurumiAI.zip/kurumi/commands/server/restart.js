export function handler(bot, m) {
    console.log(m);
    m.reply("Ini sebuah perintah restart");
    return bot;
}

handler.private = true
handler.onlyOwner = true;
handler.onlyPremium = false;
